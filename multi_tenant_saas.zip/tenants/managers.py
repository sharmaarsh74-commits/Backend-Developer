from django.db import models
from .context import get_current_tenant

class TenantManager(models.Manager):
    def get_queryset(self):
        tenant = get_current_tenant()
        if tenant is None:
            raise Exception("Tenant context not set")
        return super().get_queryset().filter(tenant=tenant)
