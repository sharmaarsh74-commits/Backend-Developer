from django.utils.deprecation import MiddlewareMixin
from .models import Tenant
from .context import set_current_tenant, clear_current_tenant

class TenantMiddleware(MiddlewareMixin):

    def process_request(self, request):
        host = request.get_host().split(":")[0]
        subdomain = host.split(".")[0]

        try:
            tenant = Tenant.objects.get(subdomain=subdomain)
            set_current_tenant(tenant)
        except Tenant.DoesNotExist:
            set_current_tenant(None)

    def process_response(self, request, response):
        clear_current_tenant()
        return response
