from django.test import TestCase
from tenants.models import Tenant
from orders.models import Order
from tenants.context import set_current_tenant, clear_current_tenant

class TenantIsolationTests(TestCase):

    def setUp(self):
        self.tenant_a = Tenant.objects.create(name="A", subdomain="a")
        self.tenant_b = Tenant.objects.create(name="B", subdomain="b")

        Order.objects.bulk_create([
            Order(tenant=self.tenant_a, item_name="A1", amount=100),
            Order(tenant=self.tenant_b, item_name="B1", amount=200),
        ])

    def test_isolation(self):
        set_current_tenant(self.tenant_a)
        self.assertEqual(Order.objects.count(), 1)
        clear_current_tenant()
