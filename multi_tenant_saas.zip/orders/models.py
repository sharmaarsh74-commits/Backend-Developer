from django.db import models
from tenants.models import Tenant
from tenants.managers import TenantManager

class Order(models.Model):
    tenant = models.ForeignKey(Tenant, on_delete=models.CASCADE)
    item_name = models.CharField(max_length=255)
    amount = models.IntegerField()

    objects = TenantManager()
